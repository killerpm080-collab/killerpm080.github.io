import React, { createContext, useContext, useState, useEffect } from 'react';
import type { CartItem, Product, Order, Customer } from '@/types';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  commissionTotal: number;
  supplierCostTotal: number;
  createOrder: (customer: Customer) => Order | null;
  orders: Order[];
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const { updateWallet } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const savedCart = localStorage.getItem('dropshippy_cart');
    const savedOrders = localStorage.getItem('dropshippy_orders');
    if (savedCart) setCartItems(JSON.parse(savedCart));
    if (savedOrders) setOrders(JSON.parse(savedOrders));
  }, []);

  useEffect(() => {
    localStorage.setItem('dropshippy_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem('dropshippy_orders', JSON.stringify(orders));
  }, [orders]);

  const addToCart = (product: Product, quantity = 1) => {
    setCartItems(prev => {
      const existingItem = prev.find(item => item.product.id === product.id);
      if (existingItem) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    toast({
      title: 'Added to cart',
      description: `${product.name} has been added to your cart.`,
    });
  };

  const removeFromCart = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const cartTotal = cartItems.reduce(
    (total, item) => total + item.product.price * item.quantity,
    0
  );

  const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  const commissionTotal = cartItems.reduce(
    (total, item) => total + item.product.commission * item.quantity,
    0
  );

  const supplierCostTotal = cartItems.reduce(
    (total, item) => total + item.product.supplierPrice * item.quantity,
    0
  );

  const createOrder = (customer: Customer): Order | null => {
    if (cartItems.length === 0) return null;

    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      items: [...cartItems],
      totalAmount: cartTotal,
      commission: commissionTotal,
      supplierCost: supplierCostTotal,
      status: 'pending',
      customer,
      createdAt: new Date().toISOString(),
      estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    };

    setOrders(prev => [newOrder, ...prev]);
    
    // Add commission to user's wallet
    updateWallet(commissionTotal);

    // Simulate automatic supplier fulfillment
    setTimeout(() => {
      setOrders(prev =>
        prev.map(order =>
          order.id === newOrder.id
            ? { ...order, status: 'processing', trackingNumber: `TRK${Date.now()}` }
            : order
        )
      );
      
      toast({
        title: 'Order Processing',
        description: `Order ${newOrder.id} is being processed by the supplier.`,
      });
    }, 3000);

    clearCart();
    return newOrder;
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartTotal,
        cartCount,
        commissionTotal,
        supplierCostTotal,
        createOrder,
        orders,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
