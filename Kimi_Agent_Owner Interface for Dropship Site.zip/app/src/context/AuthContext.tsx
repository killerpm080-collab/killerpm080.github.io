import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, Wallet, Transaction, WithdrawalRequest, PlatformStats, AdminActivity } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  adminLogin: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  connectPayoneer: (email: string) => void;
  updateWallet: (amount: number) => void;
  // Admin functions
  withdrawalRequests: WithdrawalRequest[];
  approveWithdrawal: (id: string) => void;
  rejectWithdrawal: (id: string) => void;
  platformStats: PlatformStats;
  adminActivities: AdminActivity[];
  addAdminActivity: (action: string, entityType: AdminActivity['entityType'], entityId: string, details: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const mockUser: User = {
  id: 'u1',
  name: 'Alex Johnson',
  email: 'alex@dropshippy.com',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=60',
  role: 'seller',
  payoneerConnected: false,
  storeName: 'Alex\'s Premium Store',
  createdAt: '2024-01-15',
  wallet: {
    balance: 0,
    pendingCommission: 0,
    totalEarned: 0,
    transactions: [],
  },
};

const mockAdmin: User = {
  id: 'admin1',
  name: 'Platform Owner',
  email: 'admin@dropshippy.com',
  avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&auto=format&fit=crop&q=60',
  role: 'admin',
  payoneerConnected: true,
  payoneerEmail: 'admin@dropshippy.com',
  storeName: 'DropShippy Platform',
  createdAt: '2024-01-01',
  wallet: {
    balance: 0,
    pendingCommission: 0,
    totalEarned: 0,
    transactions: [],
  },
};

const mockWithdrawalRequests: WithdrawalRequest[] = [
  {
    id: 'w1',
    amount: 245.50,
    method: 'payoneer',
    status: 'pending',
    requestedAt: '2024-03-08T10:30:00Z',
    userId: 'u1',
    userName: 'Alex Johnson',
    userEmail: 'alex@dropshippy.com',
  },
  {
    id: 'w2',
    amount: 189.00,
    method: 'payoneer',
    status: 'pending',
    requestedAt: '2024-03-07T14:20:00Z',
    userId: 'u2',
    userName: 'Sarah Smith',
    userEmail: 'sarah@example.com',
  },
  {
    id: 'w3',
    amount: 567.25,
    method: 'payoneer',
    status: 'completed',
    requestedAt: '2024-03-05T09:15:00Z',
    processedAt: '2024-03-06T11:30:00Z',
    userId: 'u3',
    userName: 'Mike Brown',
    userEmail: 'mike@example.com',
  },
];

const mockPlatformStats: PlatformStats = {
  totalProducts: 24,
  totalOrders: 156,
  totalRevenue: 28450.75,
  totalCommission: 12456.50,
  totalUsers: 47,
  totalSuppliers: 6,
  pendingWithdrawals: 2,
  pendingOrders: 12,
};

const mockAdminActivities: AdminActivity[] = [
  {
    id: 'a1',
    action: 'Product Added',
    entityType: 'product',
    entityId: 'p25',
    details: 'Added new product: Smart Watch Pro',
    timestamp: '2024-03-09T08:30:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a2',
    action: 'Order Updated',
    entityType: 'order',
    entityId: 'ORD-1234',
    details: 'Updated order status to Delivered',
    timestamp: '2024-03-09T07:15:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a3',
    action: 'Withdrawal Approved',
    entityType: 'withdrawal',
    entityId: 'w3',
    details: 'Approved withdrawal of $567.25 for Mike Brown',
    timestamp: '2024-03-08T16:45:00Z',
    adminName: 'Platform Owner',
  },
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>(mockWithdrawalRequests);
  const [platformStats] = useState<PlatformStats>(mockPlatformStats);
  const [adminActivities, setAdminActivities] = useState<AdminActivity[]>(mockAdminActivities);

  useEffect(() => {
    const savedUser = localStorage.getItem('dropshippy_user');
    if (savedUser) {
      const parsed = JSON.parse(savedUser);
      setUser(parsed);
      setIsAuthenticated(true);
      setIsAdmin(parsed.role === 'admin');
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    if (email && password) {
      const newUser = { ...mockUser, email };
      setUser(newUser);
      setIsAuthenticated(true);
      setIsAdmin(false);
      localStorage.setItem('dropshippy_user', JSON.stringify(newUser));
      return true;
    }
    return false;
  };

  const adminLogin = async (email: string, password: string): Promise<boolean> => {
    // Admin login - check for admin credentials
    if (email === 'admin@dropshippy.com' && password) {
      setUser(mockAdmin);
      setIsAuthenticated(true);
      setIsAdmin(true);
      localStorage.setItem('dropshippy_user', JSON.stringify(mockAdmin));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    localStorage.removeItem('dropshippy_user');
  };

  const connectPayoneer = (email: string) => {
    if (user) {
      const updatedUser = { ...user, payoneerConnected: true, payoneerEmail: email };
      setUser(updatedUser);
      localStorage.setItem('dropshippy_user', JSON.stringify(updatedUser));
    }
  };

  const updateWallet = (amount: number) => {
    if (user) {
      const newTransaction: Transaction = {
        id: `t${Date.now()}`,
        type: 'commission',
        amount: amount,
        description: 'Order commission earned',
        date: new Date().toISOString(),
        status: 'completed',
      };

      const updatedWallet: Wallet = {
        balance: user.wallet.balance + amount,
        pendingCommission: user.wallet.pendingCommission,
        totalEarned: user.wallet.totalEarned + amount,
        transactions: [newTransaction, ...user.wallet.transactions],
      };

      const updatedUser = { ...user, wallet: updatedWallet };
      setUser(updatedUser);
      localStorage.setItem('dropshippy_user', JSON.stringify(updatedUser));
    }
  };

  const approveWithdrawal = (id: string) => {
    setWithdrawalRequests(prev =>
      prev.map(w =>
        w.id === id
          ? { ...w, status: 'completed', processedAt: new Date().toISOString() }
          : w
      )
    );
    addAdminActivity('Withdrawal Approved', 'withdrawal', id, `Approved withdrawal ${id}`);
  };

  const rejectWithdrawal = (id: string) => {
    setWithdrawalRequests(prev =>
      prev.map(w =>
        w.id === id
          ? { ...w, status: 'rejected', processedAt: new Date().toISOString() }
          : w
      )
    );
    addAdminActivity('Withdrawal Rejected', 'withdrawal', id, `Rejected withdrawal ${id}`);
  };

  const addAdminActivity = (action: string, entityType: AdminActivity['entityType'], entityId: string, details: string) => {
    const newActivity: AdminActivity = {
      id: `a${Date.now()}`,
      action,
      entityType,
      entityId,
      details,
      timestamp: new Date().toISOString(),
      adminName: user?.name || 'Admin',
    };
    setAdminActivities(prev => [newActivity, ...prev]);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated, 
      isAdmin,
      login, 
      adminLogin,
      logout, 
      connectPayoneer, 
      updateWallet,
      withdrawalRequests,
      approveWithdrawal,
      rejectWithdrawal,
      platformStats,
      adminActivities,
      addAdminActivity,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
