export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  supplierPrice: number;
  commission: number;
  category: string;
  images: string[];
  rating: number;
  reviews: number;
  stock: number;
  supplier: Supplier;
  tags: string[];
  trending?: boolean;
  bestseller?: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  location: string;
  rating: number;
  shippingTime: string;
  logo?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  totalAmount: number;
  commission: number;
  supplierCost: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  customer: Customer;
  createdAt: string;
  trackingNumber?: string;
  estimatedDelivery?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  phone: string;
}

export interface Wallet {
  balance: number;
  pendingCommission: number;
  totalEarned: number;
  transactions: Transaction[];
}

export interface Transaction {
  id: string;
  type: 'commission' | 'withdrawal' | 'refund';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'admin' | 'seller';
  wallet: Wallet;
  payoneerConnected: boolean;
  payoneerEmail?: string;
  storeName?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  productCount: number;
}

export interface WithdrawalRequest {
  id: string;
  amount: number;
  method: 'payoneer';
  status: 'pending' | 'processing' | 'completed' | 'rejected';
  requestedAt: string;
  processedAt?: string;
  userId: string;
  userName: string;
  userEmail: string;
}

export interface PlatformStats {
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
  totalCommission: number;
  totalUsers: number;
  totalSuppliers: number;
  pendingWithdrawals: number;
  pendingOrders: number;
}

export interface AdminActivity {
  id: string;
  action: string;
  entityType: 'product' | 'order' | 'user' | 'supplier' | 'withdrawal';
  entityId: string;
  details: string;
  timestamp: string;
  adminName: string;
}
