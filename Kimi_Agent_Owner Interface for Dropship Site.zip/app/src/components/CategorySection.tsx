import { Link } from 'react-router-dom';
import { Smartphone, Dog, Home, Heart, Mountain, Shirt } from 'lucide-react';
import { categories } from '@/data/products';

const iconMap: Record<string, React.ElementType> = {
  Smartphone,
  Dog,
  Home,
  Heart,
  Mountain,
  Shirt,
};

export function CategorySection() {
  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900">
            Browse by Category
          </h2>
          <p className="text-slate-600 mt-3 max-w-2xl mx-auto">
            Explore our curated collection of winning products across popular categories
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => {
            const Icon = iconMap[category.icon] || Smartphone;
            return (
              <Link
                key={category.id}
                to={`/products?category=${encodeURIComponent(category.name)}`}
                className="group bg-white p-6 rounded-2xl border border-slate-200 hover:border-violet-300 hover:shadow-lg transition-all duration-300"
              >
                <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-violet-600 transition-colors">
                  <Icon className="w-6 h-6 text-violet-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-semibold text-slate-900 text-sm">
                  {category.name}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {category.productCount} products
                </p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
