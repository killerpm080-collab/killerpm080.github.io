import type { Product } from '@/types';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  title?: string;
  subtitle?: string;
  showViewAll?: boolean;
  onViewAll?: () => void;
}

export function ProductGrid({ 
  products, 
  title, 
  subtitle,
  showViewAll = false,
  onViewAll 
}: ProductGridProps) {
  return (
    <section className="py-12">
      {(title || subtitle) && (
        <div className="flex items-end justify-between mb-8">
          <div>
            {title && (
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="text-slate-600 mt-2">{subtitle}</p>
            )}
          </div>
          {showViewAll && onViewAll && (
            <button
              onClick={onViewAll}
              className="text-violet-600 font-medium hover:text-violet-700 transition-colors"
            >
              View All →
            </button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}
