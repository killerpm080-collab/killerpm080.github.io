import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, TrendingUp, Zap, Shield } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-slate-50 via-white to-violet-50">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-violet-200 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-indigo-200 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-violet-100 rounded-full">
              <TrendingUp className="w-4 h-4 text-violet-600" />
              <span className="text-sm font-medium text-violet-700">
                500+ Winning Products
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight">
              Start Your{' '}
              <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                Dropshipping
              </span>{' '}
              Empire Today
            </h1>

            <p className="text-lg text-slate-600 max-w-xl">
              Connect with verified suppliers, sell winning products, and earn commissions 
              on every order. We handle fulfillment while you focus on growing your business.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link to="/products">
                <Button 
                  size="lg" 
                  className="bg-violet-600 hover:bg-violet-700 text-white gap-2"
                >
                  Browse Products
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link to="/trending">
                <Button 
                  size="lg" 
                  variant="outline"
                  className="border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  View Trending
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-violet-100 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-violet-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">50%+</p>
                  <p className="text-sm text-slate-500">Profit Margins</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">100%</p>
                  <p className="text-sm text-slate-500">Verified Suppliers</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Content - Featured Products Grid */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4 mt-8">
                <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-100">
                  <img
                    src="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=300&auto=format&fit=crop&q=60"
                    alt="Wireless Earbuds"
                    className="w-full h-32 object-cover rounded-xl"
                  />
                  <p className="mt-3 font-semibold text-slate-900">Wireless Earbuds</p>
                  <p className="text-violet-600 font-bold">$89.99</p>
                  <p className="text-xs text-green-600">+$44.99 commission</p>
                </div>
                <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-100">
                  <img
                    src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=300&auto=format&fit=crop&q=60"
                    alt="Pet Camera"
                    className="w-full h-32 object-cover rounded-xl"
                  />
                  <p className="mt-3 font-semibold text-slate-900">Smart Pet Camera</p>
                  <p className="text-violet-600 font-bold">$119.99</p>
                  <p className="text-xs text-green-600">+$61.99 commission</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-100">
                  <img
                    src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&auto=format&fit=crop&q=60"
                    alt="Boucle Chair"
                    className="w-full h-32 object-cover rounded-xl"
                  />
                  <p className="mt-3 font-semibold text-slate-900">Bouclé Chair</p>
                  <p className="text-violet-600 font-bold">$299.99</p>
                  <p className="text-xs text-green-600">+$149.99 commission</p>
                </div>
                <div className="bg-gradient-to-br from-violet-600 to-indigo-600 p-4 rounded-2xl shadow-lg">
                  <div className="h-32 flex flex-col items-center justify-center text-white">
                    <TrendingUp className="w-12 h-12 mb-2" />
                    <p className="text-2xl font-bold">500+</p>
                    <p className="text-sm opacity-90">Products</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
