import { Link } from 'react-router-dom';
import { ShoppingCart, Star, TrendingUp, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Product } from '@/types';
import { useCart } from '@/context/CartContext';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  return (
    <Card className="group overflow-hidden border-slate-200 hover:shadow-xl transition-all duration-300">
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-slate-100">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </Link>
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.bestseller && (
            <Badge className="bg-amber-500 text-white border-0">
              <Award className="w-3 h-3 mr-1" />
              Bestseller
            </Badge>
          )}
          {product.trending && !product.bestseller && (
            <Badge className="bg-violet-600 text-white border-0">
              <TrendingUp className="w-3 h-3 mr-1" />
              Trending
            </Badge>
          )}
        </div>

        {/* Commission Badge */}
        <div className="absolute top-3 right-3">
          <Badge variant="secondary" className="bg-green-100 text-green-700 border-0 text-xs">
            +${product.commission.toFixed(2)}
          </Badge>
        </div>

        {/* Quick Add Button */}
        <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-black/60 to-transparent">
          <Button
            onClick={() => addToCart(product)}
            className="w-full bg-white text-slate-900 hover:bg-slate-100"
            size="sm"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Quick Add
          </Button>
        </div>
      </div>

      {/* Content */}
      <CardContent className="p-4">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-semibold text-slate-900 line-clamp-2 hover:text-violet-600 transition-colors">
            {product.name}
          </h3>
        </Link>

        <p className="text-sm text-slate-500 mt-1 line-clamp-2">
          {product.description}
        </p>

        {/* Rating */}
        <div className="flex items-center gap-2 mt-2">
          <div className="flex items-center">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span className="text-sm font-medium text-slate-700 ml-1">
              {product.rating}
            </span>
          </div>
          <span className="text-sm text-slate-400">({product.reviews})</span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mt-3">
          <div>
            <span className="text-lg font-bold text-violet-600">
              ${product.price.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 block">
              Supplier: ${product.supplierPrice.toFixed(2)}
            </span>
          </div>
          <Button
            onClick={() => addToCart(product)}
            size="sm"
            className="bg-violet-600 hover:bg-violet-700 text-white"
          >
            <ShoppingCart className="w-4 h-4" />
          </Button>
        </div>

        {/* Supplier Info */}
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-100">
          <div className="w-6 h-6 bg-slate-200 rounded-full flex items-center justify-center text-xs font-medium text-slate-600">
            {product.supplier.name.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-600 truncate">{product.supplier.name}</p>
            <p className="text-xs text-slate-400">{product.supplier.shippingTime}</p>
          </div>
          <div className="flex items-center">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span className="text-xs text-slate-600 ml-0.5">{product.supplier.rating}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
