import { Zap, Shield, Truck, DollarSign, Headphones, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: TrendingUp,
    title: 'Winning Products',
    description: 'Curated selection of trending products with high profit margins and proven demand.',
  },
  {
    icon: Shield,
    title: 'Verified Suppliers',
    description: 'All suppliers are vetted and rated to ensure quality products and reliable fulfillment.',
  },
  {
    icon: Zap,
    title: 'Auto Fulfillment',
    description: 'Orders are automatically sent to suppliers for processing and shipping to customers.',
  },
  {
    icon: DollarSign,
    title: 'Instant Commissions',
    description: 'Earn commissions on every sale. Commission goes to your wallet immediately.',
  },
  {
    icon: Truck,
    title: 'Global Shipping',
    description: 'Suppliers ship worldwide with tracking numbers provided for every order.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Our support team is available around the clock to help you succeed.',
  },
];

export function FeaturesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900">
            Why Choose DropShippy?
          </h2>
          <p className="text-slate-600 mt-3 max-w-2xl mx-auto">
            Everything you need to build a successful dropshipping business
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-violet-200 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-violet-600" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
