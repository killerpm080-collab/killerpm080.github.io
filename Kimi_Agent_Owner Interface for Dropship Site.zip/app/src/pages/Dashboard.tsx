import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Wallet,
  TrendingUp,
  DollarSign,
  Package,
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  CheckCircle,
  Clock,
  Building2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';

export function Dashboard() {
  const { user, connectPayoneer } = useAuth();
  const { orders } = useCart();
  const [showPayoneerDialog, setShowPayoneerDialog] = useState(false);
  const [showWithdrawDialog, setShowWithdrawDialog] = useState(false);
  const [payoneerEmail, setPayoneerEmail] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const totalOrders = orders.length;
  const pendingOrders = orders.filter((o) => o.status === 'pending' || o.status === 'processing').length;
  const completedOrders = orders.filter((o) => o.status === 'delivered').length;
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const totalCommission = orders.reduce((sum, o) => sum + o.commission, 0);

  const handleConnectPayoneer = () => {
    if (payoneerEmail) {
      connectPayoneer(payoneerEmail);
      setShowPayoneerDialog(false);
    }
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (amount > 0 && amount <= (user?.wallet.balance || 0)) {
      // In a real app, this would process the withdrawal
      setShowWithdrawDialog(false);
      setWithdrawAmount('');
    }
  };

  const recentTransactions = user?.wallet.transactions.slice(0, 5) || [];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-600 mt-2">
            Welcome back, {user?.name}! Here's your business overview.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Wallet Balance</p>
                  <p className="text-2xl font-bold text-slate-900">
                    ${user?.wallet.balance.toFixed(2) || '0.00'}
                  </p>
                </div>
                <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-violet-600" />
                </div>
              </div>
              <div className="mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => setShowWithdrawDialog(true)}
                  disabled={!user?.wallet.balance}
                >
                  Withdraw
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Total Commission</p>
                  <p className="text-2xl font-bold text-green-600">
                    ${totalCommission.toFixed(2)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <ArrowUpRight className="w-4 h-4 mr-1" />
                <span>Earned from {totalOrders} orders</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Total Orders</p>
                  <p className="text-2xl font-bold text-slate-900">{totalOrders}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-4 text-sm">
                <span className="text-amber-600">{pendingOrders} pending</span>
                <span className="text-green-600">{completedOrders} delivered</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Total Revenue</p>
                  <p className="text-2xl font-bold text-slate-900">
                    ${totalRevenue.toFixed(2)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-indigo-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-slate-500">
                <span>From your store sales</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Recent Orders */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Orders</CardTitle>
                <Link to="/orders">
                  <Button variant="ghost" size="sm">
                    View All
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {orders.length > 0 ? (
                  <div className="space-y-4">
                    {orders.slice(0, 5).map((order) => (
                      <div
                        key={order.id}
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-slate-900">{order.id}</p>
                          <p className="text-sm text-slate-500">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-slate-900">
                            ${order.totalAmount.toFixed(2)}
                          </p>
                          <p className="text-sm text-green-600">
                            +${order.commission.toFixed(2)}
                          </p>
                        </div>
                        <Badge
                          variant={
                            order.status === 'delivered'
                              ? 'default'
                              : order.status === 'shipped'
                              ? 'secondary'
                              : 'outline'
                          }
                        >
                          {order.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Package className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No orders yet</p>
                    <Link to="/products">
                      <Button variant="outline" className="mt-4">
                        Start Selling
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Transactions */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                {recentTransactions.length > 0 ? (
                  <div className="space-y-4">
                    {recentTransactions.map((transaction) => (
                      <div
                        key={transaction.id}
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                              transaction.type === 'commission'
                                ? 'bg-green-100'
                                : transaction.type === 'withdrawal'
                                ? 'bg-amber-100'
                                : 'bg-slate-100'
                            }`}
                          >
                            {transaction.type === 'commission' ? (
                              <ArrowUpRight className="w-5 h-5 text-green-600" />
                            ) : transaction.type === 'withdrawal' ? (
                              <ArrowDownRight className="w-5 h-5 text-amber-600" />
                            ) : (
                              <Clock className="w-5 h-5 text-slate-600" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium text-slate-900 capitalize">
                              {transaction.type}
                            </p>
                            <p className="text-sm text-slate-500">
                              {new Date(transaction.date).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p
                            className={`font-medium ${
                              transaction.type === 'commission'
                                ? 'text-green-600'
                                : transaction.type === 'withdrawal'
                                ? 'text-amber-600'
                                : 'text-slate-600'
                            }`}
                          >
                            {transaction.type === 'commission' ? '+' : '-'}
                            ${transaction.amount.toFixed(2)}
                          </p>
                          <Badge variant="outline" className="text-xs">
                            {transaction.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Clock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No transactions yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Payoneer Status */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                {user?.payoneerConnected ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                      <div>
                        <p className="font-medium text-green-900">Payoneer Connected</p>
                        <p className="text-sm text-green-700">{user.payoneerEmail}</p>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600">
                      Your earnings will be sent to your Payoneer account.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-amber-50 rounded-lg">
                      <Building2 className="w-6 h-6 text-amber-600" />
                      <div>
                        <p className="font-medium text-amber-900">Connect Payoneer</p>
                        <p className="text-sm text-amber-700">To receive withdrawals</p>
                      </div>
                    </div>
                    <Button
                      className="w-full bg-violet-600 hover:bg-violet-700 text-white"
                      onClick={() => setShowPayoneerDialog(true)}
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Connect Payoneer
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to="/products">
                  <Button variant="outline" className="w-full justify-start">
                    <Package className="w-4 h-4 mr-2" />
                    Browse Products
                  </Button>
                </Link>
                <Link to="/orders">
                  <Button variant="outline" className="w-full justify-start">
                    <Clock className="w-4 h-4 mr-2" />
                    View Orders
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Store Info */}
            <Card>
              <CardHeader>
                <CardTitle>Store Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-slate-500">Store Name</p>
                  <p className="font-medium text-slate-900">{user?.storeName || 'My Store'}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Email</p>
                  <p className="font-medium text-slate-900">{user?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Member Since</p>
                  <p className="font-medium text-slate-900">
                    {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : '-'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Payoneer Dialog */}
      <Dialog open={showPayoneerDialog} onOpenChange={setShowPayoneerDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Connect Payoneer Account</DialogTitle>
            <DialogDescription>
              Enter your Payoneer email to connect your account for withdrawals.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label htmlFor="payoneer-email">Payoneer Email</Label>
              <Input
                id="payoneer-email"
                type="email"
                value={payoneerEmail}
                onChange={(e) => setPayoneerEmail(e.target.value)}
                placeholder="your@email.com"
              />
            </div>
            <Button
              onClick={handleConnectPayoneer}
              className="w-full bg-violet-600 hover:bg-violet-700 text-white"
              disabled={!payoneerEmail}
            >
              Connect Account
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Withdraw Dialog */}
      <Dialog open={showWithdrawDialog} onOpenChange={setShowWithdrawDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Withdraw Funds</DialogTitle>
            <DialogDescription>
              Withdraw your earnings to your connected Payoneer account.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="bg-slate-50 p-4 rounded-lg">
              <p className="text-sm text-slate-500">Available Balance</p>
              <p className="text-2xl font-bold text-slate-900">
                ${user?.wallet.balance.toFixed(2)}
              </p>
            </div>
            <div>
              <Label htmlFor="withdraw-amount">Amount to Withdraw</Label>
              <Input
                id="withdraw-amount"
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="0.00"
                max={user?.wallet.balance}
              />
            </div>
            {!user?.payoneerConnected && (
              <p className="text-sm text-amber-600">
                Please connect your Payoneer account first.
              </p>
            )}
            <Button
              onClick={handleWithdraw}
              className="w-full bg-violet-600 hover:bg-violet-700 text-white"
              disabled={
                !withdrawAmount ||
                parseFloat(withdrawAmount) <= 0 ||
                parseFloat(withdrawAmount) > (user?.wallet.balance || 0) ||
                !user?.payoneerConnected
              }
            >
              Withdraw to Payoneer
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
