import { Hero } from '@/components/Hero';
import { CategorySection } from '@/components/CategorySection';
import { FeaturesSection } from '@/components/FeaturesSection';
import { ProductGrid } from '@/components/ProductGrid';
import { getTrendingProducts, getBestSellers } from '@/data/products';

export function Home() {
  const trendingProducts = getTrendingProducts().slice(0, 4);
  const bestsellerProducts = getBestSellers().slice(0, 4);

  return (
    <div className="min-h-screen">
      <Hero />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ProductGrid
          products={bestsellerProducts}
          title="Bestselling Products"
          subtitle="Our most popular products with the highest conversion rates"
          showViewAll
          onViewAll={() => window.location.href = '/bestsellers'}
        />
      </div>

      <CategorySection />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ProductGrid
          products={trendingProducts}
          title="Trending Now"
          subtitle="Hot products that are gaining popularity fast"
          showViewAll
          onViewAll={() => window.location.href = '/trending'}
        />
      </div>

      <FeaturesSection />
    </div>
  );
}
