import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Users,
  Store,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  TrendingUp as TrendingIcon,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/context/AuthContext';

const adminNavItems = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Suppliers', href: '/admin/suppliers', icon: Store },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
  { name: 'Users', href: '/admin/users', icon: Users },
  { name: 'Withdrawals', href: '/admin/withdrawals', icon: DollarSign },
  { name: 'Analytics', href: '/admin/analytics', icon: TrendingUp },
  { name: 'Activity Log', href: '/admin/activity', icon: Activity },
];

// Mock analytics data
const monthlyRevenue = [
  { month: 'Jan', revenue: 12500, orders: 45 },
  { month: 'Feb', revenue: 15200, orders: 52 },
  { month: 'Mar', revenue: 18900, orders: 68 },
  { month: 'Apr', revenue: 22400, orders: 78 },
  { month: 'May', revenue: 28100, orders: 95 },
  { month: 'Jun', revenue: 32450, orders: 112 },
];

const topProducts = [
  { name: 'Wireless Earbuds Pro', sales: 234, revenue: 21042 },
  { name: 'Smart Pet Camera', sales: 189, revenue: 22671 },
  { name: 'Bouclé Accent Chair', sales: 87, revenue: 26099 },
  { name: 'Automatic Pet Feeder', sales: 156, revenue: 14038 },
  { name: 'Peptide Lip Treatment', sales: 423, revenue: 8028 },
];

const categoryPerformance = [
  { category: 'Electronics & Gadgets', products: 24, sales: 892, revenue: 65420 },
  { category: 'Pet Products', products: 18, sales: 567, revenue: 45230 },
  { category: 'Home & Furniture', products: 15, sales: 234, revenue: 38900 },
  { category: 'Health & Wellness', products: 20, sales: 678, revenue: 28450 },
  { category: 'Outdoor & Sports', products: 12, sales: 189, revenue: 22400 },
  { category: 'Fashion & Accessories', products: 22, sales: 445, revenue: 19800 },
];

export function AdminAnalytics() {
  const { isAdmin } = useAuth();
  const [timeRange, setTimeRange] = useState('6months');

  const totalRevenue = monthlyRevenue.reduce((sum, m) => sum + m.revenue, 0);
  const totalOrders = monthlyRevenue.reduce((sum, m) => sum + m.orders, 0);
  const avgOrderValue = totalRevenue / totalOrders;

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900">Access Denied</h1>
          <Link to="/">
            <Button className="mt-4 bg-violet-600">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Admin Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold">Admin Panel</span>
              <Badge variant="secondary" className="ml-2 bg-violet-600 text-white">Owner</Badge>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="text-white hover:text-white hover:bg-slate-800">
                  View Store
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-64px)] sticky top-16">
          <nav className="p-4 space-y-1">
            {adminNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === item.href
                    ? 'bg-violet-50 text-violet-600'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Analytics</h1>
                <p className="text-slate-600 mt-2">Platform performance and insights</p>
              </div>
              <select
                className="px-4 py-2 border border-slate-300 rounded-lg bg-white"
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
              >
                <option value="7days">Last 7 Days</option>
                <option value="30days">Last 30 Days</option>
                <option value="6months">Last 6 Months</option>
                <option value="1year">Last Year</option>
              </select>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Total Revenue</p>
                      <p className="text-2xl font-bold text-slate-900">${totalRevenue.toLocaleString()}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-4 text-sm text-green-600">
                    <ArrowUpRight className="w-4 h-4" />
                    <span>+18.2%</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Total Orders</p>
                      <p className="text-2xl font-bold text-slate-900">{totalOrders}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <ShoppingCart className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-4 text-sm text-green-600">
                    <ArrowUpRight className="w-4 h-4" />
                    <span>+24.5%</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Avg Order Value</p>
                      <p className="text-2xl font-bold text-slate-900">${avgOrderValue.toFixed(2)}</p>
                    </div>
                    <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center">
                      <BarChart3 className="w-6 h-6 text-violet-600" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-4 text-sm text-red-600">
                    <ArrowDownRight className="w-4 h-4" />
                    <span>-2.1%</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Conversion Rate</p>
                      <p className="text-2xl font-bold text-slate-900">3.24%</p>
                    </div>
                    <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                      <TrendingIcon className="w-6 h-6 text-amber-600" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-4 text-sm text-green-600">
                    <ArrowUpRight className="w-4 h-4" />
                    <span>+0.8%</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-8 mb-8">
              {/* Revenue Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {monthlyRevenue.map((month) => {
                      const maxRevenue = Math.max(...monthlyRevenue.map(m => m.revenue));
                      const percentage = (month.revenue / maxRevenue) * 100;
                      return (
                        <div key={month.month}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-slate-700">{month.month}</span>
                            <span className="text-sm text-slate-500">${month.revenue.toLocaleString()}</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2">
                            <div
                              className="bg-violet-600 h-2 rounded-full transition-all"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Orders Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Orders Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {monthlyRevenue.map((month) => {
                      const maxOrders = Math.max(...monthlyRevenue.map(m => m.orders));
                      const percentage = (month.orders / maxOrders) * 100;
                      return (
                        <div key={month.month}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-slate-700">{month.month}</span>
                            <span className="text-sm text-slate-500">{month.orders} orders</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2">
                            <div
                              className="bg-blue-500 h-2 rounded-full transition-all"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Top Products */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Selling Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topProducts.map((product, index) => (
                      <div
                        key={product.name}
                        className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-violet-100 rounded-lg flex items-center justify-center text-violet-600 font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium text-slate-900">{product.name}</p>
                            <p className="text-sm text-slate-500">{product.sales} sales</p>
                          </div>
                        </div>
                        <p className="font-bold text-green-600">${product.revenue.toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Category Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>Category Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryPerformance.map((cat) => (
                      <div
                        key={cat.category}
                        className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-slate-900">{cat.category}</p>
                          <p className="text-sm text-slate-500">
                            {cat.products} products • {cat.sales} sales
                          </p>
                        </div>
                        <p className="font-bold text-violet-600">${cat.revenue.toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
