import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Users,
  Store,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Activity,
  Search,
  Package as PackageIcon,
  User,
  Store as StoreIcon,
  CreditCard,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/context/AuthContext';

const adminNavItems = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Suppliers', href: '/admin/suppliers', icon: Store },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
  { name: 'Users', href: '/admin/users', icon: Users },
  { name: 'Withdrawals', href: '/admin/withdrawals', icon: DollarSign },
  { name: 'Analytics', href: '/admin/analytics', icon: TrendingUp },
  { name: 'Activity Log', href: '/admin/activity', icon: Activity },
];

const entityIcons = {
  product: PackageIcon,
  order: ShoppingCart,
  user: User,
  supplier: StoreIcon,
  withdrawal: CreditCard,
};

const entityColors = {
  product: 'bg-blue-100 text-blue-700',
  order: 'bg-violet-100 text-violet-700',
  user: 'bg-green-100 text-green-700',
  supplier: 'bg-amber-100 text-amber-700',
  withdrawal: 'bg-pink-100 text-pink-700',
};

// Extended mock activities
const mockActivities = [
  {
    id: 'a1',
    action: 'Product Added',
    entityType: 'product' as const,
    entityId: 'p25',
    details: 'Added new product: Smart Watch Pro',
    timestamp: '2024-03-09T08:30:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a2',
    action: 'Order Updated',
    entityType: 'order' as const,
    entityId: 'ORD-1234',
    details: 'Updated order status to Delivered',
    timestamp: '2024-03-09T07:15:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a3',
    action: 'Withdrawal Approved',
    entityType: 'withdrawal' as const,
    entityId: 'w3',
    details: 'Approved withdrawal of $567.25 for Mike Brown',
    timestamp: '2024-03-08T16:45:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a4',
    action: 'User Registered',
    entityType: 'user' as const,
    entityId: 'u5',
    details: 'New user registered: John Wilson',
    timestamp: '2024-03-08T12:20:00Z',
    adminName: 'System',
  },
  {
    id: 'a5',
    action: 'Product Updated',
    entityType: 'product' as const,
    entityId: 'p1',
    details: 'Updated price for Wireless Earbuds Pro',
    timestamp: '2024-03-08T10:00:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a6',
    action: 'Supplier Added',
    entityType: 'supplier' as const,
    entityId: 's7',
    details: 'Added new supplier: TechHub Direct',
    timestamp: '2024-03-07T14:30:00Z',
    adminName: 'Platform Owner',
  },
  {
    id: 'a7',
    action: 'Order Created',
    entityType: 'order' as const,
    entityId: 'ORD-5678',
    details: 'New order created by Sarah Smith',
    timestamp: '2024-03-07T11:45:00Z',
    adminName: 'System',
  },
  {
    id: 'a8',
    action: 'Withdrawal Rejected',
    entityType: 'withdrawal' as const,
    entityId: 'w4',
    details: 'Rejected withdrawal due to insufficient balance',
    timestamp: '2024-03-06T09:20:00Z',
    adminName: 'Platform Owner',
  },
];

export function AdminActivity() {
  const { isAdmin, adminActivities } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [entityFilter, setEntityFilter] = useState('all');

  // Combine mock activities with real admin activities
  const allActivities = [...adminActivities, ...mockActivities].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const filteredActivities = allActivities.filter((activity) => {
    const matchesSearch =
      activity.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.adminName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesEntity = entityFilter === 'all' || activity.entityType === entityFilter;
    return matchesSearch && matchesEntity;
  });

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900">Access Denied</h1>
          <Link to="/">
            <Button className="mt-4 bg-violet-600">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Admin Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold">Admin Panel</span>
              <Badge variant="secondary" className="ml-2 bg-violet-600 text-white">Owner</Badge>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="text-white hover:text-white hover:bg-slate-800">
                  View Store
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-64px)] sticky top-16">
          <nav className="p-4 space-y-1">
            {adminNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === item.href
                    ? 'bg-violet-50 text-violet-600'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-slate-900">Activity Log</h1>
              <p className="text-slate-600 mt-2">Track all platform activities and changes</p>
            </div>

            {/* Filters */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 mb-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search activities..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <select
                  className="px-4 py-2 border border-slate-300 rounded-lg"
                  value={entityFilter}
                  onChange={(e) => setEntityFilter(e.target.value)}
                >
                  <option value="all">All Types</option>
                  <option value="product">Products</option>
                  <option value="order">Orders</option>
                  <option value="user">Users</option>
                  <option value="supplier">Suppliers</option>
                  <option value="withdrawal">Withdrawals</option>
                </select>
              </div>
            </div>

            {/* Activity List */}
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {filteredActivities.map((activity) => {
                    const Icon = entityIcons[activity.entityType];
                    return (
                      <div
                        key={activity.id}
                        className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                      >
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${entityColors[activity.entityType]}`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold text-slate-900">{activity.action}</p>
                            <Badge variant="outline" className="text-xs capitalize">
                              {activity.entityType}
                            </Badge>
                          </div>
                          <p className="text-sm text-slate-600 mt-1">{activity.details}</p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                            <span>By: {activity.adminName}</span>
                            <span>{new Date(activity.timestamp).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
