import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Users,
  Store,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Activity,
  Search,
  Plus,
  Edit2,
  Trash2,
  Star,
  MapPin,
  Truck,
  Package as PackageIcon,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';
import { suppliers as initialSuppliers, products } from '@/data/products';
import type { Supplier } from '@/types';

const adminNavItems = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Suppliers', href: '/admin/suppliers', icon: Store },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
  { name: 'Users', href: '/admin/users', icon: Users },
  { name: 'Withdrawals', href: '/admin/withdrawals', icon: DollarSign },
  { name: 'Analytics', href: '/admin/analytics', icon: TrendingUp },
  { name: 'Activity Log', href: '/admin/activity', icon: Activity },
];

export function AdminSuppliers() {
  const { isAdmin, addAdminActivity } = useAuth();
  const [suppliers, setSuppliers] = useState<Supplier[]>(initialSuppliers);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  
  const [newSupplier, setNewSupplier] = useState<Partial<Supplier>>({
    name: '',
    location: '',
    rating: 4.5,
    shippingTime: '7-14 days',
  });

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getSupplierProductCount = (supplierId: string) => {
    return products.filter((p) => p.supplier.id === supplierId).length;
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this supplier?')) {
      setSuppliers(suppliers.filter((s) => s.id !== id));
      addAdminActivity('Supplier Deleted', 'supplier', id, `Deleted supplier ${id}`);
    }
  };

  const handleAdd = () => {
    const supplier: Supplier = {
      ...newSupplier,
      id: `s${Date.now()}`,
    } as Supplier;
    
    setSuppliers([...suppliers, supplier]);
    setShowAddDialog(false);
    setNewSupplier({
      name: '',
      location: '',
      rating: 4.5,
      shippingTime: '7-14 days',
    });
    addAdminActivity('Supplier Added', 'supplier', supplier.id, `Added supplier: ${supplier.name}`);
  };

  const handleEdit = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setNewSupplier(supplier);
    setShowAddDialog(true);
  };

  const handleUpdate = () => {
    if (editingSupplier) {
      setSuppliers(
        suppliers.map((s) =>
          s.id === editingSupplier.id ? { ...newSupplier, id: editingSupplier.id } as Supplier : s
        )
      );
      setShowAddDialog(false);
      setEditingSupplier(null);
      addAdminActivity('Supplier Updated', 'supplier', editingSupplier.id, `Updated supplier: ${newSupplier.name}`);
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900">Access Denied</h1>
          <Link to="/">
            <Button className="mt-4 bg-violet-600">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Admin Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold">Admin Panel</span>
              <Badge variant="secondary" className="ml-2 bg-violet-600 text-white">Owner</Badge>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="text-white hover:text-white hover:bg-slate-800">
                  View Store
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-64px)] sticky top-16">
          <nav className="p-4 space-y-1">
            {adminNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === item.href
                    ? 'bg-violet-50 text-violet-600'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Suppliers</h1>
                <p className="text-slate-600 mt-2">Manage your supplier network</p>
              </div>
              <Button
                onClick={() => {
                  setEditingSupplier(null);
                  setNewSupplier({
                    name: '',
                    location: '',
                    rating: 4.5,
                    shippingTime: '7-14 days',
                  });
                  setShowAddDialog(true);
                }}
                className="bg-violet-600 hover:bg-violet-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Supplier
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Total Suppliers</p>
                      <p className="text-2xl font-bold text-slate-900">{suppliers.length}</p>
                    </div>
                    <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center">
                      <Store className="w-6 h-6 text-violet-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Avg Rating</p>
                      <p className="text-2xl font-bold text-slate-900">
                        {(suppliers.reduce((sum, s) => sum + s.rating, 0) / suppliers.length).toFixed(1)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                      <Star className="w-6 h-6 text-amber-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Total Products</p>
                      <p className="text-2xl font-bold text-slate-900">{products.length}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <PackageIcon className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Search */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search suppliers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Suppliers Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSuppliers.map((supplier) => (
                <Card key={supplier.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="w-14 h-14 bg-violet-100 rounded-xl flex items-center justify-center text-violet-600 font-bold text-xl">
                        {supplier.name.charAt(0)}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(supplier)}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(supplier.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-slate-900 mt-4">{supplier.name}</h3>

                    <div className="space-y-2 mt-4">
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <MapPin className="w-4 h-4" />
                        {supplier.location}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Truck className="w-4 h-4" />
                        {supplier.shippingTime}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        {supplier.rating} rating
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <PackageIcon className="w-4 h-4" />
                        {getSupplierProductCount(supplier.id)} products
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </main>
      </div>

      {/* Add/Edit Supplier Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label>Supplier Name</Label>
              <Input
                value={newSupplier.name}
                onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })}
                placeholder="Enter supplier name"
              />
            </div>
            <div>
              <Label>Location</Label>
              <Input
                value={newSupplier.location}
                onChange={(e) => setNewSupplier({ ...newSupplier, location: e.target.value })}
                placeholder="e.g., Shenzhen, China"
              />
            </div>
            <div>
              <Label>Shipping Time</Label>
              <Input
                value={newSupplier.shippingTime}
                onChange={(e) => setNewSupplier({ ...newSupplier, shippingTime: e.target.value })}
                placeholder="e.g., 7-14 days"
              />
            </div>
            <div>
              <Label>Rating</Label>
              <Input
                type="number"
                min="0"
                max="5"
                step="0.1"
                value={newSupplier.rating}
                onChange={(e) => setNewSupplier({ ...newSupplier, rating: parseFloat(e.target.value) })}
                placeholder="0.0 - 5.0"
              />
            </div>
            <Button
              onClick={editingSupplier ? handleUpdate : handleAdd}
              className="w-full bg-violet-600 hover:bg-violet-700"
              disabled={!newSupplier.name || !newSupplier.location}
            >
              {editingSupplier ? 'Update Supplier' : 'Add Supplier'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
