import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Users,
  Store,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Activity,
  Search,
  Plus,
  Edit2,
  Trash2,
  TrendingUp as TrendingIcon,
  Award,
  Save,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';
import { products as initialProducts, suppliers, categories } from '@/data/products';
import type { Product } from '@/types';

const adminNavItems = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Suppliers', href: '/admin/suppliers', icon: Store },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
  { name: 'Users', href: '/admin/users', icon: Users },
  { name: 'Withdrawals', href: '/admin/withdrawals', icon: DollarSign },
  { name: 'Analytics', href: '/admin/analytics', icon: TrendingUp },
  { name: 'Activity Log', href: '/admin/activity', icon: Activity },
];

export function AdminProducts() {
  const { isAdmin, addAdminActivity } = useAuth();
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    supplierPrice: 0,
    commission: 0,
    category: '',
    stock: 100,
    rating: 4.5,
    reviews: 0,
    images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=60'],
    tags: [],
    trending: false,
    bestseller: false,
  });

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      setProducts(products.filter((p) => p.id !== id));
      addAdminActivity('Product Deleted', 'product', id, `Deleted product ${id}`);
    }
  };

  const handleAdd = () => {
    const product: Product = {
      ...newProduct,
      id: `p${Date.now()}`,
      supplier: suppliers[0],
      commission: (newProduct.price || 0) - (newProduct.supplierPrice || 0),
    } as Product;
    
    setProducts([...products, product]);
    setShowAddDialog(false);
    setNewProduct({
      name: '',
      description: '',
      price: 0,
      supplierPrice: 0,
      commission: 0,
      category: '',
      stock: 100,
      rating: 4.5,
      reviews: 0,
      images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=60'],
      tags: [],
      trending: false,
      bestseller: false,
    });
    addAdminActivity('Product Added', 'product', product.id, `Added product: ${product.name}`);
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setNewProduct(product);
    setShowAddDialog(true);
  };

  const handleUpdate = () => {
    if (editingProduct) {
      setProducts(
        products.map((p) =>
          p.id === editingProduct.id
            ? { ...newProduct, id: editingProduct.id, supplier: p.supplier } as Product
            : p
        )
      );
      setShowAddDialog(false);
      setEditingProduct(null);
      addAdminActivity('Product Updated', 'product', editingProduct.id, `Updated product: ${newProduct.name}`);
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900">Access Denied</h1>
          <Link to="/">
            <Button className="mt-4 bg-violet-600">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Admin Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold">Admin Panel</span>
              <Badge variant="secondary" className="ml-2 bg-violet-600 text-white">Owner</Badge>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="text-white hover:text-white hover:bg-slate-800">
                  View Store
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-64px)] sticky top-16">
          <nav className="p-4 space-y-1">
            {adminNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === item.href
                    ? 'bg-violet-50 text-violet-600'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Products</h1>
                <p className="text-slate-600 mt-2">Manage your product catalog</p>
              </div>
              <Button
                onClick={() => {
                  setEditingProduct(null);
                  setNewProduct({
                    name: '',
                    description: '',
                    price: 0,
                    supplierPrice: 0,
                    commission: 0,
                    category: '',
                    stock: 100,
                    rating: 4.5,
                    reviews: 0,
                    images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=60'],
                    tags: [],
                    trending: false,
                    bestseller: false,
                  });
                  setShowAddDialog(true);
                }}
                className="bg-violet-600 hover:bg-violet-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </div>

            {/* Search */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Products Table */}
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Product</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Category</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Price</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Commission</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Stock</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Status</th>
                        <th className="px-6 py-4 text-right text-sm font-semibold text-slate-900">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredProducts.map((product) => (
                        <tr key={product.id} className="hover:bg-slate-50">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={product.images[0]}
                                alt={product.name}
                                className="w-12 h-12 object-cover rounded-lg"
                              />
                              <div>
                                <p className="font-medium text-slate-900">{product.name}</p>
                                <p className="text-sm text-slate-500">{product.supplier.name}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-600">{product.category}</td>
                          <td className="px-6 py-4 text-sm text-slate-900">${product.price.toFixed(2)}</td>
                          <td className="px-6 py-4 text-sm text-green-600">+${product.commission.toFixed(2)}</td>
                          <td className="px-6 py-4 text-sm text-slate-600">{product.stock}</td>
                          <td className="px-6 py-4">
                            <div className="flex gap-1">
                              {product.trending && (
                                <Badge className="bg-violet-100 text-violet-700">
                                  <TrendingIcon className="w-3 h-3 mr-1" />
                                  Trending
                                </Badge>
                              )}
                              {product.bestseller && (
                                <Badge className="bg-amber-100 text-amber-700">
                                  <Award className="w-3 h-3 mr-1" />
                                  Bestseller
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEdit(product)}
                              >
                                <Edit2 className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDelete(product.id)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {/* Add/Edit Product Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label>Product Name</Label>
              <Input
                value={newProduct.name}
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                placeholder="Enter product name"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Input
                value={newProduct.description}
                onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                placeholder="Enter product description"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Retail Price</Label>
                <Input
                  type="number"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({ ...newProduct, price: parseFloat(e.target.value) })}
                  placeholder="0.00"
                />
              </div>
              <div>
                <Label>Supplier Price</Label>
                <Input
                  type="number"
                  value={newProduct.supplierPrice}
                  onChange={(e) => setNewProduct({ ...newProduct, supplierPrice: parseFloat(e.target.value) })}
                  placeholder="0.00"
                />
              </div>
            </div>
            <div>
              <Label>Category</Label>
              <select
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                value={newProduct.category}
                onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              >
                <option value="">Select category</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Stock</Label>
              <Input
                type="number"
                value={newProduct.stock}
                onChange={(e) => setNewProduct({ ...newProduct, stock: parseInt(e.target.value) })}
                placeholder="0"
              />
            </div>
            <div className="flex gap-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={newProduct.trending}
                  onChange={(e) => setNewProduct({ ...newProduct, trending: e.target.checked })}
                />
                <span className="text-sm">Trending</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={newProduct.bestseller}
                  onChange={(e) => setNewProduct({ ...newProduct, bestseller: e.target.checked })}
                />
                <span className="text-sm">Bestseller</span>
              </label>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <p className="text-sm text-slate-600">
                Commission: <span className="font-bold text-green-600">
                  ${((newProduct.price || 0) - (newProduct.supplierPrice || 0)).toFixed(2)}
                </span>
              </p>
            </div>
            <Button
              onClick={editingProduct ? handleUpdate : handleAdd}
              className="w-full bg-violet-600 hover:bg-violet-700"
              disabled={!newProduct.name || !newProduct.category}
            >
              <Save className="w-4 h-4 mr-2" />
              {editingProduct ? 'Update Product' : 'Add Product'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
