import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Users,
  Store,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Activity,
  Search,
  Wallet,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';

const adminNavItems = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Suppliers', href: '/admin/suppliers', icon: Store },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
  { name: 'Users', href: '/admin/users', icon: Users },
  { name: 'Withdrawals', href: '/admin/withdrawals', icon: DollarSign },
  { name: 'Analytics', href: '/admin/analytics', icon: TrendingUp },
  { name: 'Activity Log', href: '/admin/activity', icon: Activity },
];

// Mock users data
const mockUsers = [
  {
    id: 'u1',
    name: 'Alex Johnson',
    email: 'alex@dropshippy.com',
    storeName: "Alex's Premium Store",
    role: 'seller',
    createdAt: '2024-01-15',
    payoneerConnected: true,
    wallet: { balance: 245.50, totalEarned: 1250.75 },
    orders: 12,
  },
  {
    id: 'u2',
    name: 'Sarah Smith',
    email: 'sarah@example.com',
    storeName: "Sarah's Boutique",
    role: 'seller',
    createdAt: '2024-02-01',
    payoneerConnected: true,
    wallet: { balance: 189.00, totalEarned: 890.50 },
    orders: 8,
  },
  {
    id: 'u3',
    name: 'Mike Brown',
    email: 'mike@example.com',
    storeName: "Mike's Electronics",
    role: 'seller',
    createdAt: '2024-02-10',
    payoneerConnected: false,
    wallet: { balance: 0, totalEarned: 567.25 },
    orders: 5,
  },
  {
    id: 'u4',
    name: 'Emily Davis',
    email: 'emily@example.com',
    storeName: "Emily's Home Goods",
    role: 'seller',
    createdAt: '2024-02-15',
    payoneerConnected: true,
    wallet: { balance: 425.00, totalEarned: 2100.00 },
    orders: 18,
  },
  {
    id: 'u5',
    name: 'John Wilson',
    email: 'john@example.com',
    storeName: "John's Sports Shop",
    role: 'seller',
    createdAt: '2024-03-01',
    payoneerConnected: false,
    wallet: { balance: 0, totalEarned: 0 },
    orders: 0,
  },
];

export function AdminUsers() {
  const { isAdmin } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<typeof mockUsers[0] | null>(null);

  const filteredUsers = mockUsers.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.storeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalEarnings = mockUsers.reduce((sum, u) => sum + u.wallet.totalEarned, 0);
  const totalActiveUsers = mockUsers.filter((u) => u.orders > 0).length;

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900">Access Denied</h1>
          <Link to="/">
            <Button className="mt-4 bg-violet-600">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Admin Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold">Admin Panel</span>
              <Badge variant="secondary" className="ml-2 bg-violet-600 text-white">Owner</Badge>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="text-white hover:text-white hover:bg-slate-800">
                  View Store
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-64px)] sticky top-16">
          <nav className="p-4 space-y-1">
            {adminNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === item.href
                    ? 'bg-violet-50 text-violet-600'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-slate-900">Users</h1>
              <p className="text-slate-600 mt-2">Manage platform sellers and their accounts</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Total Users</p>
                      <p className="text-2xl font-bold text-slate-900">{mockUsers.length}</p>
                    </div>
                    <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center">
                      <Users className="w-6 h-6 text-violet-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Active Sellers</p>
                      <p className="text-2xl font-bold text-green-600">{totalActiveUsers}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">Total Earnings Paid</p>
                      <p className="text-2xl font-bold text-slate-900">${totalEarnings.toFixed(2)}</p>
                    </div>
                    <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                      <Wallet className="w-6 h-6 text-amber-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Search */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Users Table */}
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">User</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Store</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Joined</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Orders</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Earnings</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Payoneer</th>
                        <th className="px-6 py-4 text-right text-sm font-semibold text-slate-900">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="hover:bg-slate-50">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-violet-100 rounded-full flex items-center justify-center text-violet-600 font-bold">
                                {user.name.charAt(0)}
                              </div>
                              <div>
                                <p className="font-medium text-slate-900">{user.name}</p>
                                <p className="text-sm text-slate-500">{user.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-600">{user.storeName}</td>
                          <td className="px-6 py-4 text-sm text-slate-600">
                            {new Date(user.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-900">{user.orders}</td>
                          <td className="px-6 py-4">
                            <div>
                              <p className="font-medium text-green-600">
                                ${user.wallet.totalEarned.toFixed(2)}
                              </p>
                              <p className="text-xs text-slate-500">
                                Balance: ${user.wallet.balance.toFixed(2)}
                              </p>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            {user.payoneerConnected ? (
                              <Badge className="bg-green-100 text-green-700">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Connected
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="text-slate-500">
                                <XCircle className="w-3 h-3 mr-1" />
                                Not Connected
                              </Badge>
                            )}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedUser(user)}
                            >
                              View Details
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {/* User Detail Dialog */}
      <Dialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-6 mt-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-violet-100 rounded-full flex items-center justify-center text-violet-600 font-bold text-2xl">
                  {selectedUser.name.charAt(0)}
                </div>
                <div>
                  <p className="text-xl font-bold text-slate-900">{selectedUser.name}</p>
                  <p className="text-slate-500">{selectedUser.email}</p>
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg space-y-3">
                <div className="flex justify-between">
                  <span className="text-slate-500">Store Name</span>
                  <span className="font-medium">{selectedUser.storeName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Member Since</span>
                  <span className="font-medium">{new Date(selectedUser.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Total Orders</span>
                  <span className="font-medium">{selectedUser.orders}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Payoneer Status</span>
                  <span className="font-medium">
                    {selectedUser.payoneerConnected ? 'Connected' : 'Not Connected'}
                  </span>
                </div>
              </div>

              <div className="bg-violet-50 p-4 rounded-lg">
                <h4 className="font-semibold text-violet-900 mb-3">Wallet</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-violet-700">Current Balance</span>
                    <span className="font-bold text-violet-900">
                      ${selectedUser.wallet.balance.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-violet-700">Total Earned</span>
                    <span className="font-bold text-green-600">
                      ${selectedUser.wallet.totalEarned.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
