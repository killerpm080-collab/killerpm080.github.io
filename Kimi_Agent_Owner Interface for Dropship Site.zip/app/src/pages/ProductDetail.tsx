import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ShoppingCart, 
  Star, 
  Truck, 
  Shield, 
  ArrowLeft,
  Minus,
  Plus,
  Check,
  TrendingUp,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getProductById, products } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { ProductCard } from '@/components/ProductCard';

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const product = getProductById(id || '');
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900">Product Not Found</h1>
          <p className="text-slate-600 mt-2">The product you're looking for doesn't exist.</p>
          <Link to="/products">
            <Button className="mt-4 bg-violet-600">Browse Products</Button>
          </Link>
        </div>
      </div>
    );
  }

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <Link
          to="/products"
          className="inline-flex items-center text-sm text-slate-600 hover:text-violet-600 mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Products
        </Link>

        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-8 p-8">
            {/* Image */}
            <div className="relative">
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-full aspect-square object-cover rounded-xl"
              />
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.bestseller && (
                  <Badge className="bg-amber-500 text-white border-0">
                    <Award className="w-3 h-3 mr-1" />
                    Bestseller
                  </Badge>
                )}
                {product.trending && (
                  <Badge className="bg-violet-600 text-white border-0">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Trending
                  </Badge>
                )}
              </div>
            </div>

            {/* Info */}
            <div className="space-y-6">
              <div>
                <p className="text-sm text-violet-600 font-medium">{product.category}</p>
                <h1 className="text-3xl font-bold text-slate-900 mt-1">{product.name}</h1>
                
                {/* Rating */}
                <div className="flex items-center gap-3 mt-3">
                  <div className="flex items-center">
                    <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                    <span className="font-semibold text-slate-900 ml-1">{product.rating}</span>
                  </div>
                  <span className="text-slate-400">|</span>
                  <span className="text-slate-600">{product.reviews} reviews</span>
                  <span className="text-slate-400">|</span>
                  <span className="text-green-600 font-medium">{product.stock} in stock</span>
                </div>
              </div>

              <p className="text-slate-600 leading-relaxed">{product.description}</p>

              {/* Pricing */}
              <div className="bg-slate-50 p-4 rounded-xl space-y-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-violet-600">
                    ${product.price.toFixed(2)}
                  </span>
                  <span className="text-slate-400">retail price</span>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <div>
                    <span className="text-slate-500">Your cost:</span>
                    <span className="ml-1 font-medium text-slate-700">
                      ${product.supplierPrice.toFixed(2)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Your profit:</span>
                    <span className="ml-1 font-bold text-green-600">
                      ${product.commission.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Quantity */}
              <div>
                <label className="text-sm font-medium text-slate-700">Quantity</label>
                <div className="flex items-center gap-3 mt-2">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 rounded-lg border border-slate-300 flex items-center justify-center hover:bg-slate-50"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-semibold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 rounded-lg border border-slate-300 flex items-center justify-center hover:bg-slate-50"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-4">
                <Button
                  onClick={handleAddToCart}
                  size="lg"
                  className="flex-1 bg-violet-600 hover:bg-violet-700 text-white"
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Add to Cart
                </Button>
              </div>

              {/* Features */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <Truck className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">Fast Shipping</p>
                    <p className="text-xs text-slate-500">{product.supplier.shippingTime}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Shield className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">Verified Supplier</p>
                    <p className="text-xs text-slate-500">{product.supplier.rating}★ rating</p>
                  </div>
                </div>
              </div>

              {/* Supplier Info */}
              <div className="bg-slate-50 p-4 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-violet-100 rounded-full flex items-center justify-center text-lg font-bold text-violet-600">
                    {product.supplier.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-slate-900">{product.supplier.name}</p>
                    <p className="text-sm text-slate-500">{product.supplier.location}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      <span className="font-semibold ml-1">{product.supplier.rating}</span>
                    </div>
                    <p className="text-xs text-slate-500">Supplier rating</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-t border-slate-200">
            <Tabs defaultValue="details" className="p-8">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="details">Product Details</TabsTrigger>
                <TabsTrigger value="shipping">Shipping Info</TabsTrigger>
                <TabsTrigger value="supplier">Supplier</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="mt-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-slate-900">Product Features</h3>
                  <ul className="space-y-2">
                    {product.tags.map((tag, index) => (
                      <li key={index} className="flex items-center gap-2 text-slate-600">
                        <Check className="w-4 h-4 text-green-500" />
                        {tag.charAt(0).toUpperCase() + tag.slice(1)}
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>
              
              <TabsContent value="shipping" className="mt-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-slate-900">Shipping Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="font-medium text-slate-900">Processing Time</p>
                      <p className="text-slate-600">1-2 business days</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="font-medium text-slate-900">Shipping Time</p>
                      <p className="text-slate-600">{product.supplier.shippingTime}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="font-medium text-slate-900">Shipping From</p>
                      <p className="text-slate-600">{product.supplier.location}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="font-medium text-slate-900">Tracking</p>
                      <p className="text-slate-600">Tracking number provided</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="supplier" className="mt-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-slate-900">About the Supplier</h3>
                  <p className="text-slate-600">
                    {product.supplier.name} is a verified supplier with a {product.supplier.rating}★ 
                    rating. They are located in {product.supplier.location} and typically ship orders 
                    within {product.supplier.shippingTime}.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">Verified</Badge>
                    <Badge variant="secondary">Fast Shipping</Badge>
                    <Badge variant="secondary">Quality Products</Badge>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Related Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
