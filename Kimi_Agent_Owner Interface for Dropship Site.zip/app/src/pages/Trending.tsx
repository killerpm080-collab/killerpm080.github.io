import { TrendingUp, Flame, Star } from 'lucide-react';
import { ProductGrid } from '@/components/ProductGrid';
import { products, getTrendingProducts, getBestSellers } from '@/data/products';
import { Card, CardContent } from '@/components/ui/card';

export function Trending() {
  const trendingProducts = getTrendingProducts();
  const bestsellerProducts = getBestSellers();

  // Calculate some stats
  const avgCommission = products.reduce((sum, p) => sum + p.commission, 0) / products.length;
  const highestCommission = Math.max(...products.map(p => p.commission));
  const trendingCount = trendingProducts.length;

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-violet-100 rounded-full mb-4">
            <Flame className="w-5 h-5 text-violet-600" />
            <span className="text-sm font-medium text-violet-700">Hot Right Now</span>
          </div>
          <h1 className="text-4xl font-bold text-slate-900">Trending Products</h1>
          <p className="text-slate-600 mt-4 max-w-2xl mx-auto">
            Discover the hottest products that are flying off the shelves. 
            These items have proven demand and high conversion rates.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-violet-600" />
              </div>
              <p className="text-3xl font-bold text-slate-900">{trendingCount}</p>
              <p className="text-slate-600">Trending Products</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-3xl font-bold text-slate-900">
                ${avgCommission.toFixed(2)}
              </p>
              <p className="text-slate-600">Avg. Commission</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Flame className="w-6 h-6 text-amber-600" />
              </div>
              <p className="text-3xl font-bold text-slate-900">
                ${highestCommission.toFixed(2)}
              </p>
              <p className="text-slate-600">Highest Commission</p>
            </CardContent>
          </Card>
        </div>

        {/* Bestsellers Section */}
        {bestsellerProducts.length > 0 && (
          <div className="mb-16">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                <Star className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Bestsellers</h2>
                <p className="text-slate-600">Our most popular products with highest sales</p>
              </div>
            </div>
            <ProductGrid products={bestsellerProducts} />
          </div>
        )}

        {/* All Trending */}
        <div>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-violet-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-900">All Trending Products</h2>
              <p className="text-slate-600">Hot products gaining popularity fast</p>
            </div>
          </div>
          <ProductGrid products={trendingProducts} />
        </div>
      </div>
    </div>
  );
}
