import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Package,
  Search,
  ChevronDown,
  ChevronUp,
  Truck,
  CheckCircle,
  Clock,
  XCircle,
  Eye,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { useCart } from '@/context/CartContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { Order } from '@/types';

const statusConfig = {
  pending: { icon: Clock, color: 'amber', label: 'Pending' },
  processing: { icon: Package, color: 'blue', label: 'Processing' },
  shipped: { icon: Truck, color: 'violet', label: 'Shipped' },
  delivered: { icon: CheckCircle, color: 'green', label: 'Delivered' },
  cancelled: { icon: XCircle, color: 'red', label: 'Cancelled' },
};

export function Orders() {
  const { orders } = useCart();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.email.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const toggleExpand = (orderId: string) => {
    setExpandedOrder(expandedOrder === orderId ? null : orderId);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">My Orders</h1>
          <p className="text-slate-600 mt-2">
            Track and manage all your dropshipping orders
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search orders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="shipped">Shipped</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Orders List */}
        {filteredOrders.length > 0 ? (
          <div className="space-y-4">
            {filteredOrders.map((order) => {
              const status = statusConfig[order.status];
              const StatusIcon = status.icon;
              const isExpanded = expandedOrder === order.id;

              return (
                <Card key={order.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    {/* Order Header */}
                    <div
                      className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50"
                      onClick={() => toggleExpand(order.id)}
                    >
                      <div className="flex items-center gap-4">
                        <div
                          className={`w-10 h-10 bg-${status.color}-100 rounded-lg flex items-center justify-center`}
                        >
                          <StatusIcon className={`w-5 h-5 text-${status.color}-600`} />
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900">{order.id}</p>
                          <p className="text-sm text-slate-500">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      <div className="hidden md:block">
                        <p className="text-sm text-slate-500">{order.items.length} items</p>
                        <p className="text-sm text-slate-900">{order.customer.name}</p>
                      </div>

                      <div className="text-right">
                        <p className="font-semibold text-slate-900">
                          ${order.totalAmount.toFixed(2)}
                        </p>
                        <p className="text-sm text-green-600">
                          +${order.commission.toFixed(2)} commission
                        </p>
                      </div>

                      <div className="flex items-center gap-4">
                        <Badge
                          variant={
                            order.status === 'delivered'
                              ? 'default'
                              : order.status === 'cancelled'
                              ? 'destructive'
                              : 'secondary'
                          }
                        >
                          {status.label}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedOrder(order);
                          }}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {/* Expanded Details */}
                    {isExpanded && (
                      <div className="border-t border-slate-200 p-4 bg-slate-50">
                        <div className="grid md:grid-cols-2 gap-6">
                          {/* Items */}
                          <div>
                            <h4 className="font-semibold text-slate-900 mb-3">Order Items</h4>
                            <div className="space-y-3">
                              {order.items.map((item) => (
                                <div
                                  key={item.product.id}
                                  className="flex items-center gap-3 bg-white p-3 rounded-lg"
                                >
                                  <img
                                    src={item.product.images[0]}
                                    alt={item.product.name}
                                    className="w-12 h-12 object-cover rounded"
                                  />
                                  <div className="flex-1">
                                    <p className="text-sm font-medium text-slate-900">
                                      {item.product.name}
                                    </p>
                                    <p className="text-xs text-slate-500">
                                      Qty: {item.quantity} × ${item.product.price}
                                    </p>
                                  </div>
                                  <p className="text-sm font-medium">
                                    ${(item.product.price * item.quantity).toFixed(2)}
                                  </p>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Customer & Shipping */}
                          <div>
                            <h4 className="font-semibold text-slate-900 mb-3">
                              Customer Information
                            </h4>
                            <div className="bg-white p-4 rounded-lg space-y-2">
                              <p className="text-sm">
                                <span className="text-slate-500">Name:</span>{' '}
                                {order.customer.name}
                              </p>
                              <p className="text-sm">
                                <span className="text-slate-500">Email:</span>{' '}
                                {order.customer.email}
                              </p>
                              <p className="text-sm">
                                <span className="text-slate-500">Phone:</span>{' '}
                                {order.customer.phone}
                              </p>
                              <p className="text-sm">
                                <span className="text-slate-500">Address:</span>
                                <br />
                                {order.customer.address}
                                <br />
                                {order.customer.city}, {order.customer.state}{' '}
                                {order.customer.zipCode}
                                <br />
                                {order.customer.country}
                              </p>
                            </div>

                            {order.trackingNumber && (
                              <div className="mt-4">
                                <h4 className="font-semibold text-slate-900 mb-2">
                                  Shipping Information
                                </h4>
                                <div className="bg-white p-4 rounded-lg">
                                  <p className="text-sm">
                                    <span className="text-slate-500">Tracking Number:</span>{' '}
                                    <span className="font-medium">{order.trackingNumber}</span>
                                  </p>
                                  {order.estimatedDelivery && (
                                    <p className="text-sm mt-1">
                                      <span className="text-slate-500">Estimated Delivery:</span>{' '}
                                      {new Date(order.estimatedDelivery).toLocaleDateString()}
                                    </p>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900">No orders found</h3>
            <p className="text-slate-600 mt-2">
              {searchQuery || statusFilter !== 'all'
                ? 'Try adjusting your filters'
                : 'Start selling to see your orders here'}
            </p>
            {!searchQuery && statusFilter === 'all' && (
              <Link to="/products">
                <Button className="mt-4 bg-violet-600">Browse Products</Button>
              </Link>
            )}
          </div>
        )}
      </div>

      {/* Order Detail Dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Order Details - {selectedOrder?.id}</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6 mt-4">
              <div className="flex items-center justify-between">
                <Badge
                  variant={
                    selectedOrder.status === 'delivered'
                      ? 'default'
                      : selectedOrder.status === 'cancelled'
                      ? 'destructive'
                      : 'secondary'
                  }
                >
                  {statusConfig[selectedOrder.status].label}
                </Badge>
                <p className="text-sm text-slate-500">
                  {new Date(selectedOrder.createdAt).toLocaleString()}
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-slate-900">Items</h4>
                {selectedOrder.items.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex items-center gap-3 bg-slate-50 p-3 rounded-lg"
                  >
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">{item.product.name}</p>
                      <p className="text-sm text-slate-500">
                        Qty: {item.quantity} × ${item.product.price}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </p>
                      <p className="text-sm text-green-600">
                        +${(item.product.commission * item.quantity).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-slate-200 pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Subtotal</span>
                  <span>${selectedOrder.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-slate-500">Supplier Cost</span>
                  <span className="text-slate-600">
                    ${selectedOrder.supplierCost.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-slate-500">Your Commission</span>
                  <span className="text-green-600 font-medium">
                    +${selectedOrder.commission.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between font-semibold text-lg mt-4 pt-4 border-t border-slate-200">
                  <span>Total</span>
                  <span className="text-violet-600">
                    ${selectedOrder.totalAmount.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
